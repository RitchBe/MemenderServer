var express = require('express');
var app = express();

app.get('/', function(req, res){
  console.log('Send message on request');
  res.send('Oh hello')
});

app.set('port', process.env.PORT || 3000);

var server = app.listen(app.get('port'), function () {
  console.log('Express up and running at ' + server.address().port);
})
